// 1. REPLACE THIS WITH YOUR API GATEWAY INVOKE URL
const API_URL = 'https://sluh937jo9.execute-api.ap-southeast-1.amazonaws.com/stage01';

// Function to show a notification
function showNotification(message, isSuccess = true) {
    const notification = document.createElement('div');
    notification.className = `notification ${isSuccess ? 'success' : 'error'}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background: ${isSuccess ? '#4CAF50' : '#f44336'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 1000;
        animation: slideIn 0.3s ease, fadeOut 0.3s ease 2.7s forwards;
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}

// Add keyframes for the notification animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(style);

// 2. Function to load events from the API
function loadEvents() {
    const eventsList = document.getElementById('eventsList');
    
    eventsList.innerHTML = `
        <div class="event-card event-card-skeleton">
            <div class="skeleton-line"></div>
            <div class="skeleton-line short"></div>
            <div class="skeleton-line shorter"></div>
        </div>
        <div class="event-card event-card-skeleton">
            <div class="skeleton-line"></div>
            <div class="skeleton-line short"></div>
            <div class="skeleton-line shorter"></div>
        </div>
    `;

    fetch(API_URL, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'   // ✅ keep it consistent
        }
    })
    .then(response => response.json())
    .then(data => {
        eventsList.innerHTML = ''; 

        if (Array.isArray(data) && data.length > 0) {
            data.forEach((event, index) => {
                const eventElement = document.createElement('div');
                eventElement.className = 'event-card';
                eventElement.style.animationDelay = `${index * 0.1}s`;
                eventElement.innerHTML = `
                    <div class="event-content">
                        <h3>${event.name}</h3>
                        <p><strong>Date:</strong> ${event.date}</p>
                        <p><strong>Location:</strong> ${event.location}</p>
                        <p>${event.description}</p>
                    </div>
                `;
                eventsList.appendChild(eventElement);
            });
        } else {
            eventsList.innerHTML = `
                <div class="no-events">
                    <h3>No events yet</h3>
                    <p>Be the first to add an event!</p>
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error loading events:', error);
        eventsList.innerHTML = `<p class="error">Failed to load events. Please check the console.</p>`;
    });
}

// 3. Function to add a new event via the API
function addEvent() {
    const name = document.getElementById('eventName').value;
    const date = document.getElementById('eventDate').value;
    const location = document.getElementById('eventLocation').value;
    const description = document.getElementById('eventDescription').value;

    if (!name || !date || !location || !description) {
        showNotification('Please fill in all fields.', false);
        return;
    }

    const eventData = { name, date, location, description };

    fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'   // ✅ FIXED HERE
        },
        body: JSON.stringify(eventData)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        showNotification('Event added successfully! 🎉');
        
        document.getElementById('eventName').value = '';
        document.getElementById('eventDate').value = '';
        document.getElementById('eventLocation').value = '';
        document.getElementById('eventDescription').value = '';
        
        loadEvents();
    })
    .catch(error => {
        console.error('Error adding event:', error);
        showNotification('Failed to add event. Please try again.', false);
    });
}

// Load events when the page finishes loading
window.onload = loadEvents;
